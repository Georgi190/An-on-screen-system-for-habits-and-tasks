const STORAGE_KEY = "pulse-habit-app-state-v1";

const demoTasks = [
  {
    id: crypto.randomUUID(),
    title: "Morning stretch",
    category: "Health",
    progress: 72,
    urgent: false,
    completed: false,
    today: true,
    notes: "10 minutes of mobility before breakfast."
  },
  {
    id: crypto.randomUUID(),
    title: "Rodan Barue",
    category: "Work",
    progress: 88,
    urgent: true,
    completed: false,
    today: true,
    notes: "Prepare the main concept presentation for the client."
  },
  {
    id: crypto.randomUUID(),
    title: "Inbox zero",
    category: "Personal",
    progress: 54,
    urgent: false,
    completed: false,
    today: true,
    notes: "Clean up the mail backlog and archive old threads."
  },
  {
    id: crypto.randomUUID(),
    title: "Deep work block",
    category: "Focus",
    progress: 61,
    urgent: true,
    completed: false,
    today: false,
    notes: "No notifications for 90 minutes."
  },
  {
    id: crypto.randomUUID(),
    title: "Water tracker",
    category: "Health",
    progress: 100,
    urgent: false,
    completed: true,
    today: true,
    notes: "Reached the daily hydration goal."
  },
  {
    id: crypto.randomUUID(),
    title: "Weekly review",
    category: "Growth",
    progress: 40,
    urgent: false,
    completed: false,
    today: false,
    notes: "Review wins, misses, and next week priorities."
  }
];

const defaultState = {
  view: "today",
  query: "",
  selectedCategory: "All",
  showCompleted: true,
  compactMode: false,
  modalOpen: false,
  editingTaskId: null,
  tasks: demoTasks
};

let state = loadState();

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function loadState() {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return structuredClone(defaultState);

  try {
    const parsed = JSON.parse(raw);
    return {
      ...structuredClone(defaultState),
      ...parsed,
      tasks: Array.isArray(parsed.tasks) && parsed.tasks.length ? parsed.tasks : structuredClone(defaultState.tasks)
    };
  } catch {
    return structuredClone(defaultState);
  }
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function setState(patch) {
  state = { ...state, ...patch };
  saveState();
  renderApp();
}

function updateTasks(updater) {
  state = { ...state, tasks: updater(state.tasks) };
  saveState();
  renderApp();
}

function getCategories(tasks = state.tasks) {
  return ["All", ...new Set(tasks.map((task) => task.category))];
}

function getVisibleTasks() {
  return state.tasks.filter((task) => {
    if (state.view === "today" && !task.today) return false;
    if (!state.showCompleted && task.completed) return false;
    if (state.selectedCategory !== "All" && task.category !== state.selectedCategory) return false;
    if (state.query.trim()) {
      const haystack = `${task.title} ${task.category} ${task.notes}`.toLowerCase();
      if (!haystack.includes(state.query.trim().toLowerCase())) return false;
    }
    return true;
  });
}

function getProgressStroke(progress) {
  const radius = 11;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (progress / 100) * circumference;
  return { circumference, offset };
}

function openModal(taskId = null) {
  state = { ...state, modalOpen: true, editingTaskId: taskId };
  renderApp();
}

function closeModal() {
  state = { ...state, modalOpen: false, editingTaskId: null };
  renderApp();
}

function getEditingTask() {
  return state.tasks.find((task) => task.id === state.editingTaskId) || null;
}

function renderTask(task) {
  const ring = getProgressStroke(task.progress);
  const tags = [
    `<span>${escapeHtml(task.category)}</span>`,
    task.today ? "<span>Today</span>" : "<span>Later</span>",
    task.urgent ? "<span>Urgent</span>" : ""
  ].join("");

  return `
    <article class="task-item ${task.completed ? "is-complete" : ""} ${state.compactMode ? "is-compact" : ""}">
      <button class="task-check" data-action="toggle-complete" data-task-id="${task.id}" aria-label="${task.completed ? "Mark as not completed" : "Mark as completed"}">
        <span class="task-check-inner"></span>
      </button>

      <button class="task-body" data-action="edit-task" data-task-id="${task.id}">
        <div class="task-copy">
          <h3>${escapeHtml(task.title)}</h3>
          <div class="task-tags">${tags}</div>
          ${state.compactMode ? "" : `<p>${escapeHtml(task.notes || "No details yet.")}</p>`}
          <div class="progress">
            <span class="progress-fill" style="width:${task.progress}%"></span>
          </div>
        </div>
      </button>

      <button class="task-ring" data-action="cycle-progress" data-task-id="${task.id}" aria-label="Update progress for ${task.title}">
        <svg viewBox="0 0 28 28" aria-hidden="true">
          <circle class="ring-bg" cx="14" cy="14" r="11"></circle>
          <circle class="ring-progress" cx="14" cy="14" r="11" stroke-dasharray="${ring.circumference}" stroke-dashoffset="${ring.offset}"></circle>
        </svg>
        <span>${task.progress}</span>
      </button>
    </article>
  `;
}

function renderTaskList() {
  const visibleTasks = getVisibleTasks();
  if (!visibleTasks.length) {
    return `
      <div class="empty-state">
        <strong>Nothing here yet</strong>
        <p>Try another filter or add a new task with the plus button.</p>
      </div>
    `;
  }

  return visibleTasks.map(renderTask).join("");
}

function renderCategoryCards() {
  return getCategories()
    .filter((category) => category !== "All")
    .map((category) => {
      const tasks = state.tasks.filter((task) => task.category === category);
      const completed = tasks.filter((task) => task.completed).length;
      const percent = tasks.length ? Math.round((completed / tasks.length) * 100) : 0;

      return `
        <article class="category-card">
          <div>
            <h3>${escapeHtml(category)}</h3>
            <p>${tasks.length} task${tasks.length === 1 ? "" : "s"}</p>
          </div>
          <div class="category-meta">
            <strong>${percent}%</strong>
            <button data-action="select-category" data-category="${escapeHtml(category)}">Open</button>
          </div>
        </article>
      `;
    })
    .join("");
}

function renderSettings() {
  return `
    <section class="settings-panel">
      <label class="setting-row">
        <span>Show completed tasks</span>
        <input type="checkbox" data-action="toggle-setting" data-setting="showCompleted" ${state.showCompleted ? "checked" : ""}>
      </label>
      <label class="setting-row">
        <span>Compact mode</span>
        <input type="checkbox" data-action="toggle-setting" data-setting="compactMode" ${state.compactMode ? "checked" : ""}>
      </label>
      <button class="settings-btn" data-action="reset-demo">Reset demo data</button>
      <button class="settings-btn secondary" data-action="open-add-modal">Add quick task</button>
    </section>
  `;
}

function renderScreenContent() {
  if (state.view === "categories") {
    return `<section class="screen-section categories-grid">${renderCategoryCards()}</section>`;
  }
  if (state.view === "settings") {
    return renderSettings();
  }
  return `<section class="screen-section task-list">${renderTaskList()}</section>`;
}

function renderCategoryFilters() {
  return getCategories()
    .map((category) => `
      <button class="filter-chip ${state.selectedCategory === category ? "is-active" : ""}" data-action="select-category" data-category="${escapeHtml(category)}">
        ${escapeHtml(category)}
      </button>
    `)
    .join("");
}

function renderModal() {
  const editingTask = getEditingTask();
  if (!state.modalOpen) return "";

  return `
    <div class="modal-backdrop" data-action="close-modal">
      <div class="task-modal" role="dialog" aria-modal="true" aria-label="${editingTask ? "Edit task" : "Add task"}">
        <div class="modal-header">
          <h2>${editingTask ? "Edit task" : "Add a new task"}</h2>
          <button class="icon-btn" data-action="close-modal" aria-label="Close modal">×</button>
        </div>

        <form class="task-form" id="task-form">
          <label>
            <span>Title</span>
            <input name="title" maxlength="48" required value="${editingTask ? escapeHtml(editingTask.title) : ""}">
          </label>
          <label>
            <span>Category</span>
            <select name="category">
              ${["Work", "Personal", "Health", "Focus", "Growth"].map((category) => `
                <option value="${escapeHtml(category)}" ${editingTask?.category === category ? "selected" : ""}>${escapeHtml(category)}</option>
              `).join("")}
            </select>
          </label>
          <label class="grid-span">
            <span>Notes</span>
            <textarea name="notes" rows="3" maxlength="120">${editingTask ? escapeHtml(editingTask.notes) : ""}</textarea>
          </label>
          <label>
            <span>Progress</span>
            <input name="progress" type="range" min="0" max="100" value="${editingTask ? editingTask.progress : 40}">
          </label>
          <label class="checkbox-row">
            <input name="today" type="checkbox" ${editingTask ? (editingTask.today ? "checked" : "") : "checked"}>
            <span>Show in Today</span>
          </label>
          <label class="checkbox-row">
            <input name="urgent" type="checkbox" ${editingTask?.urgent ? "checked" : ""}>
            <span>Mark as urgent</span>
          </label>
          <div class="form-actions">
            ${editingTask ? `<button type="button" class="danger-btn" data-action="delete-task" data-task-id="${editingTask.id}">Delete</button>` : "<span></span>"}
            <button type="submit" class="primary-btn">${editingTask ? "Save changes" : "Create task"}</button>
          </div>
        </form>
      </div>
    </div>
  `;
}

function renderApp() {
  const root = document.querySelector("#app");
  const counts = {
    today: state.tasks.filter((task) => task.today && !task.completed).length,
    all: state.tasks.filter((task) => !task.completed).length
  };

  root.innerHTML = `
    <main class="page">
      <article class="project-card">
        <section class="hero-panel">
          <div class="hero-glow hero-glow-left"></div>
          <div class="hero-glow hero-glow-right"></div>

          <button class="floating-chip top-chip" data-action="quick-view" data-view="all">MOBILE CONCEPT</button>
          <button class="floating-chip bottom-chip" data-action="quick-view" data-view="today">RETENTION-FIRST UX</button>

          <div class="phone">
            <div class="phone-frame">
              <div class="phone-notch"></div>
              <div class="phone-screen">
                <div class="screen-ambient"></div>

                <div class="toolbar">
                  <label class="searchbar" aria-label="Search tasks">
                    <span class="search-icon"></span>
                    <input class="search-input" type="text" placeholder="Search tasks" value="${escapeHtml(state.query)}">
                  </label>
                  <button class="add-btn" type="button" data-action="open-add-modal" aria-label="Add task">+</button>
                </div>

                <div class="accent-line"></div>

                <div class="filter-row">
                  ${renderCategoryFilters()}
                </div>

                ${renderScreenContent()}

                <nav class="bottom-nav" aria-label="App sections">
                  <button class="nav-item ${state.view === "today" ? "is-current" : ""}" data-action="change-view" data-view="today">Today<span>${counts.today}</span></button>
                  <button class="nav-item ${state.view === "all" ? "is-current" : ""}" data-action="change-view" data-view="all">All<span>${counts.all}</span></button>
                  <button class="nav-item ${state.view === "categories" ? "is-current" : ""}" data-action="change-view" data-view="categories">Categories<span>${getCategories().length - 1}</span></button>
                  <button class="nav-item ${state.view === "settings" ? "is-current" : ""}" data-action="change-view" data-view="settings">Settings<span>UI</span></button>
                </nav>
              </div>
            </div>
          </div>
        </section>

        <section class="card-copy">
          <div class="meta-row">
            <span>APP</span>
            <span>2026</span>
          </div>
          <h1>Pulse Habit</h1>
          <p>
            Экранная система для привычек и задач, где чистая навигация
            сочетается с живой современной подачей.
          </p>
          <div class="pill-row">
            <button data-action="select-category" data-category="Health">Mobile UI</button>
            <button data-action="change-view" data-view="categories">UX</button>
            <button data-action="change-view" data-view="all">Product flow</button>
          </div>
          <button class="card-link" data-action="open-add-modal">Хочу такой уровень <span aria-hidden="true">↗</span></button>
        </section>
      </article>

      ${renderModal()}
    </main>
  `;
}

function handleAction(target) {
  const actionElement = target.closest("[data-action]");
  if (!actionElement) return;

  const { action, view, category, taskId, setting } = actionElement.dataset;

  if (action === "change-view") {
    setState({ view });
    return;
  }

  if (action === "quick-view") {
    setState({ view, selectedCategory: "All" });
    return;
  }

  if (action === "select-category") {
    setState({
      selectedCategory: category,
      view: state.view === "settings" ? "all" : category === "All" && state.view === "categories" ? "all" : state.view
    });
    return;
  }

  if (action === "open-add-modal") {
    openModal();
    return;
  }

  if (action === "close-modal") {
    if (target.closest(".task-modal") && !target.classList.contains("icon-btn")) return;
    closeModal();
    return;
  }

  if (action === "toggle-complete") {
    updateTasks((tasks) =>
      tasks.map((task) =>
        task.id === taskId
          ? { ...task, completed: !task.completed, progress: task.completed ? Math.max(task.progress, 20) : 100 }
          : task
      )
    );
    return;
  }

  if (action === "cycle-progress") {
    updateTasks((tasks) =>
      tasks.map((task) => {
        if (task.id !== taskId) return task;
        const nextProgress = task.progress >= 100 ? 0 : Math.min(100, task.progress + 20);
        return { ...task, progress: nextProgress, completed: nextProgress === 100 };
      })
    );
    return;
  }

  if (action === "edit-task") {
    openModal(taskId);
    return;
  }

  if (action === "toggle-setting") {
    setState({ [setting]: target.checked });
    return;
  }

  if (action === "reset-demo") {
    state = structuredClone(defaultState);
    saveState();
    renderApp();
    return;
  }

  if (action === "delete-task") {
    updateTasks((tasks) => tasks.filter((task) => task.id !== taskId));
    closeModal();
  }
}

document.addEventListener("click", (event) => {
  handleAction(event.target);
});

document.addEventListener("input", (event) => {
  if (event.target.classList.contains("search-input")) {
    setState({ query: event.target.value });
  }
});

document.addEventListener("submit", (event) => {
  const form = event.target;
  if (!(form instanceof HTMLFormElement) || form.id !== "task-form") return;

  event.preventDefault();

  const formData = new FormData(form);
  const editingTask = getEditingTask();
  const nextTask = {
    id: editingTask ? editingTask.id : crypto.randomUUID(),
    title: String(formData.get("title") || "").trim(),
    category: String(formData.get("category") || "Personal"),
    notes: String(formData.get("notes") || "").trim(),
    progress: Number(formData.get("progress") || 0),
    today: formData.get("today") === "on",
    urgent: formData.get("urgent") === "on",
    completed: Number(formData.get("progress") || 0) >= 100
  };

  if (!nextTask.title) return;

  updateTasks((tasks) => {
    if (editingTask) {
      return tasks.map((task) => (task.id === editingTask.id ? nextTask : task));
    }
    return [nextTask, ...tasks];
  });

  closeModal();
});

renderApp();
